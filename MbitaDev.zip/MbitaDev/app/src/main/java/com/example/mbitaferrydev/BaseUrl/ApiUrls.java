package com.example.mbitaferrydev.BaseUrl;

public class ApiUrls {
    public static final String apiUrl = "http://apis.mobiticket.co.ke/v3/mbitaferry";
    public static final String allferyapiUrl = "http://apis.mobiticket.co.ke/v3/mbitaferry1";

    public static final String refGeneration = "http://server1.mobiticket.co.ke/api/v1/users";

}
