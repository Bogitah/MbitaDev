package com.example.mbitaferrydev.Models;

public class Routes {
    String name;

    public Routes(String s) {
        this.name = s;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
